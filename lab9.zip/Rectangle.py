class Rectangle():
	'''
	Create a Rectangle
	param list: x - an integer
				y - an integer
				h - an integer
				w - an integer
	return: a string contain x, y, h, w values
	'''
	def __init__(self, x, y, h, w):
		self.x = x
		self.y = y
		self.height = h
		self.width = w
	def __str__(self):
		return '(x:' + str(self.x) + ',' + 'y:' + str(self.y) + ')' + 'width:' + str(self.height) + ',height:' + str(self.width)
	
