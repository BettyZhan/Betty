print(“=====Standard Input Test=====”)
	test_ship.moveRight(5)
	assert  test_ship.getCoordinates() == (5, 0)
