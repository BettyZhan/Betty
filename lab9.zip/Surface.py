import Rectangle


class Surface():
	'''
	Create a class surface
	param list: filename - a string
				x - an integer
				y - an integer
				h - an integer
				w - an integer
	return: self.rect
	'''
	def __init__(self, filename, x, y, h, w):
		self.rect = Rectangle.Rectangle(x, y, h, w)
		self.image = filename
	def getRect(self):
		return self.rect