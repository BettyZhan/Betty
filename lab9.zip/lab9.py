import Surface
import Rectangle


def main():
	surface_object = Surface.Surface('picture', 0, 0, 2, 3)
	result = surface_object.getRect()
	print(result)
main()