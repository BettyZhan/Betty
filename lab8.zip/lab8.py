import cipher


def main():
	message = input('Please enter a string (q to Quit): ')
	while message !='q':
		encrypted_text, code = cipher.encrypt(message)
		print('the message encrypted by cipher: ', encrypted_text)
		print('the cipher: ', code)
		whe_continue = input('Would you like to decrypt your message (y/n)? ')
		if whe_continue == 'y':
			print('the message decrypted: ', cipher.decrypt(encrypted_text, code))
		message = input('Please enter a string (q to Quit): ')
	print('Goodbye!')
	
main()
		
	