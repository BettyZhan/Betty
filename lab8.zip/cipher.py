import random
	
		
def encrypt(text):
	'''
	Randomly creates a dictionary and encrypt message
	param list: text - a string
	return: encrypt_text - a string
			cipher - a dictionary
	'''
	# Randomly create a dictionary
	cipher = {}
	for i in range(32,127):
		value = chr(random.randrange(32,127))
		while value in cipher.values():
			value = chr(random.randrange(32,127))
		cipher[chr(i)] = value
	
	# Encrypt the message	
	encrypt_text = ''	
	for letter in text:
		encrypt_text += cipher.get(letter, '')
	return encrypt_text, cipher

		
def decrypt(text, cipher):
	'''
	Decrypt message
	param list: text - a string
				cipher - a dictionary
	return: unencrypted_message - a string
	'''
	# Switch keys and values in original dictionary and same them in a new dictionary
	un_cipher = {}
	for (k,v) in cipher.items():
		un_cipher[v] = k
	
	# Decrypt the message by match key and value in the dictionary 
	unencrypted_message = ''
	for letter in text:
		unencrypted_message  += un_cipher.get(letter, '')
	return unencrypted_message





