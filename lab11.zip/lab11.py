import LSystem

def main():
	filenames = [ 'donotexist.txt', 'hilbertcurve.txt', 'dragoncurve.txt', 'arrowheadcurve.txt', 
				'peanogospercurve.txt', 'sierpinskitrianglecurve.txt']
				
	for i in filenames:
		sys = LSystem.LSystem(i)
		sys.drawCurve()
main()
		

