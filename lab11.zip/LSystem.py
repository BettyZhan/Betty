import turtle
import random

class LSystem:
	'''
	Create an L-System class that that takes a filename, and reads in a set of symbols and rules.
	'''

	def __init__(self, filename):
		'''
		Reads in the rules, angle, and iterations from files, then stores them all.
		'''
		try:
			self.lines = []
			self.file = open(filename)
			for line in self.file:
				self.lines += [line]
			self.angle = int(self.lines[0].strip())
			self.iterations = int(self.lines[1].strip()) 
			self.axiom = self.lines[2].strip()
			self.rules = self.lines[3:]
			
		except:
			print("File doesn't exit! Draw a Defalted picture")
			self.angle = 30
			self.iterations = 5 
			self.axiom = 'FY'
			self.rules = ['F:F+--FF','Y:Y+Y+Y+F']

				
	
	def applyRules(self, char):
		'''
		According to the rules, change letters to the substitutes.
		param list: char - a string (a letter that to apply the rule)
		return: self.replace
		'''
		self.replace = char
		self.rules_sep = []
		for rules_sep_str in self.rules:
			self.rules_sep = rules_sep_str.split(":")
			if char == self.rules_sep[0].strip():
				self.replace = self.rules_sep[1].strip()
		return self.replace
			
				
	def processString(self):
		'''
		Apply the rules to axiom.
		param list: None
		return: self.newstr 
		'''
		self.newstr = ''
		for char in self.axiom:
			self.newstr += self.applyRules(char)
		return self.newstr	
	
	def createLSystem(self):
		'''
		Runs the transformations on the axiom for a number of 
		iterations as specified by iterations.
		param list: Nonw
		return: self.axiom
		'''
		for i in range(self.iterations):
			self.axiom = self.processString()
		return self.axiom


	def drawCurve(self):
		'''
		Draws the LSystem based on each character in the orders string.
		param list: None
		return: None
		'''
		self.createLSystem()
		self.betty = turtle.Turtle()
		self.wn= turtle.Screen()
		self.betty.speed(0)
		self.colorlist = ['red', 'blue', 'yellow', 'orange']
		for letter in self.axiom:
			self.betty.color(random.choice(self.colorlist))
			if letter == "F":
				self.betty.forward(4)
			elif letter == "+":
				self.betty.left(self.angle)
			elif letter == "-":
				self.betty.right(self.angle)
		self.betty.goto(0,0)
		self.betty.clear()

		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		