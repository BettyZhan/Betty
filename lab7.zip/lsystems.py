import turtle
import random

def applyRules(char, rules):
	'''
	According to the rules, change letters to the substitutes.
	param list: char - a string (a letter that to apply the rule)
				rules - a list (a combined stirngs)
	return: replace
	'''
	replace = char
	rules_sep = []
	for rules_sep_str in rules:
		rules_sep = rules_sep_str.split(":")
		if char == rules_sep[0]:
			replace = rules_sep[1]
	return replace
			
				
def processString(axiom, rules):
	'''
	Apply the rules to axiom.
	param list: axiom - a string
				rules - a list
	return: newstr 
	'''
	newstr = ''
	for char in axiom:
		newstr += applyRules(char, rules)
	return newstr	

def createLSystem(iterations, axiom, rules):
	'''
	Runs the transformations on the axiom for a number of 
	iterations as specified by iterations.
	param list: iterations - an integer
				axiom - a string
				rules - a list
	return: axiom
	'''
	for i in range(iterations):
		axiom = processString(axiom, rules)
	return axiom


def drawLSystem(orders, distance, degree):
	'''
	Draws the LSystem based on each character in the orders string.
	param list: orders - a string
				distance - an float
				degree - a float
	return: None
	'''
	betty = turtle.Turtle()
	wn = turtle.Screen()
	betty.speed(0)
	colorlist = ['red', 'blue', 'yellow', 'orange']
	for letter in orders:
		betty.color(random.choice(colorlist))
		if letter == "F":
			betty.forward(distance)
		elif letter == "+":
			betty.left(degree)
		elif letter == "-":
			betty.right(degree)
	wn.exitonclick()


			
	

		
		

	
		