import lsystems


def set_rules_list(rules, num_rules):
	'''
	Ask the user to input the rule in the specified format, “character:substitution”, 
	and store each rule string in a combined list.
	param list: rules - a list (to store each rule string)
				num_rules - an integer (how many rules is going to put in) 
	return: None
	'''
	for i in range(num_rules):
		rules_single = input('please input the rules  in the specified format, “character:substitution”: ') 
		rules.append(rules_single)
	

def main():
	# Asks the user to input all the information.
	axiom = input("plese input the axiom: ")
	iterations = int(input("please input the number of iterations: "))
	degree = float(input("please input the angle: "))
	distance = float(input("please input the distance: "))
	num_rules = int(input("please input the number of rules: "))
	
	#create a empty list and ask the user to input rules and store each rule string in the list.
	rules =[]
	set_rules_list(rules, num_rules)
	
	orders = lsystems.createLSystem(iterations, axiom, rules)
	lsystems.drawLSystem(orders, distance, degree)
main()
	
